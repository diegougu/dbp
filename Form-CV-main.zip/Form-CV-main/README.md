# Form-CV
Form a CV in Xamarin.Forms
<h1>Fotos de ejemplo:</h1><br>

![CV](https://github.com/NikolasZM/Form-CV/assets/101744161/28816c1d-3db9-41a3-9b50-f10b3dc36cee)
![Forms](https://github.com/NikolasZM/Form-CV/assets/101744161/151ee473-80f2-46cb-a972-12cd123c611c)
